%include <typemaps/factory.swg>
