#!/data/data/com.example.yada/files/usr/bin/sh

echo "$@"
