##
## This script is sourced by /data/data/com.example.yada/files/usr/bin/login before executing shell.
##
