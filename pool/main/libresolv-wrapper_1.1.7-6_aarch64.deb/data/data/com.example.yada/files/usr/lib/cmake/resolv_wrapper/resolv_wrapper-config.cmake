set(RESOLV_WRAPPER_LIBRARY /data/data/com.example.yada/files/usr/lib/libresolv_wrapper.so)
